# -*- coding: utf-8 -*-
"""
Created on Sat Oct 26 08:22:45 2024

@author: Automatizacion 2
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import signal
from scipy.signal import find_peaks
import pywt

#%%Lectura y carga de datos 
with open(r'C:\Users\valen\OneDrive\Desktop\Ingenieria Biomedica\VI semestre\Procesamiento digital de señales\Laboratorio de señales\Lab4a\Lab4\datosECG4.csv', 'r', encoding='utf-8') as file:

    lines = file.readlines()

#reemplazando comas por puntos
data = []
for line in lines:
    line = line.strip().replace(',', '.')  # Elimina espacios y reemplaza comas
    try:
        value = float(line)
        data.append(value)
    except ValueError:
        continue

data = np.array(data)
fs = 250  
print(data[:5]) # verificar los datos


tiempo = np.arange(len(data)) / fs # Generar el eje de tiempo

# Graficar la señal
plt.figure(figsize=(50, 10))
plt.plot(tiempo, data, color='red')
plt.title("Señal ECG")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.grid()
plt.show()

#%%ESTADÍSTICAS DE LA SENAL CRUDA

# Calcular estadísticas 
media = np.mean(data)
mediana = np.median(data)
desviacion= np.std(data)

# Imprimir estadísticas generales
print(f"Media de la señal original: {media:.4f}")
print(f"Mediana de la señal original : {mediana:.4f}")
print(f"Desviación estándar de la señal original: {desviacion:.4f}")


#%%FILTROS 

# Parámetros del filtro pasa banda
lc = 5.0    # Frecuencia de corte baja para el pasa banda
hc = 100.0   # Frecuencia de corte alta para el pasa banda
order_bandpass = 3  # Orden del filtro pasa banda

# Normalización para el filtro pasa banda
nyquist = 0.5 * fs
low = lc / nyquist
high = hc / nyquist

# Filtro pasa banda Butterworth
b_bandpass, a_bandpass = signal.butter(order_bandpass, [low, high], btype='band')
filtered_data = signal.filtfilt(b_bandpass, a_bandpass, data)

# Parámetros para el filtro de rechaza banda 
stop_low = 50.0
stop_high = 60.0
order_bandstop = 5  # Orden del filtro rechaza banda
low_stop = stop_low / nyquist
high_stop = stop_high / nyquist

# Filtro rechaza banda Butterworth
b_bandstop, a_bandstop = signal.butter(order_bandstop, [low_stop, high_stop], btype='bandstop')
filtered_bandstop_data = signal.filtfilt(b_bandstop, a_bandstop, filtered_data)

# Genera el eje de tiempo
tiempo = np.arange(len(data)) / fs

# Gráficas
plt.figure(figsize=(50, 8))

plt.subplot(3, 1, 1)
plt.plot(tiempo, data, color='red')
plt.title("Señal ECG Original")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.grid()

plt.subplot(3, 1, 2)
plt.plot(tiempo, filtered_data, color='green')
plt.title(f"Señal ECG Filtrada (Pasa banda {lc}-{hc} Hz, Orden {order_bandpass})")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.grid()

plt.subplot(3, 1, 3)
plt.plot(tiempo, filtered_bandstop_data, color='blue')
plt.title(f"Señal ECG Filtrada (Pasa Banda + Rechaza Banda {stop_low}-{stop_high} Hz, Orden {order_bandstop})")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.grid()

plt.tight_layout()
plt.show()

#%%DETECCION DE INTERVALOS R-R

distance = int(0.6 * fs)  #Distancia mínima entre picos (600 ms aprox.)
peaks, _ = find_peaks(filtered_bandstop_data, distance=distance, height=0.5)  # heigh: amplitud


# Calcular los intervalos R-R
intervalos_RR = np.diff(peaks) / fs  
num_picos = len(peaks)
num_intervalos = len(intervalos_RR)


tiempo_RR = np.cumsum(intervalos_RR)  # Tiempo acumulado de cada intervalo R-R

# Imprimir información
print(f"Número de picos R detectados: {num_picos}")
print(f"Número de intervalos R-R: {num_intervalos}")
print(f"Duración de cada intervalo R-R en segundos: {intervalos_RR}")

# Gráfica de la señal con los picos R marcados
plt.figure(figsize=(50, 10))
plt.plot(tiempo, filtered_bandstop_data, label='Señal ECG Filtrada', color='blue')
plt.plot(tiempo[peaks], filtered_bandstop_data[peaks], "x", label="Picos R", color='red')  # Marcamos los picos R
plt.title("Señal ECG filtrada con picos R identificados")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.legend()
plt.grid()


#%%ESTADÍSTICAS DE LOS INTERVALOS R-R

# Calcular estadísticas de los intervalos R-R
media_RR = np.mean(intervalos_RR)
mediana_RR = np.median(intervalos_RR)
desviacion_std_RR = np.std(intervalos_RR)

# Imprimir estadísticas generales
print(f"Media de los intervalos R-R: {media_RR:.4f} segundos")
print(f"Mediana de los intervalos R-R: {mediana_RR:.4f} segundos")
print(f"Desviación estándar de los intervalos R-R: {desviacion_std_RR:.4f} segundos")


# Gráfica de los intervalos R-R 
plt.figure(figsize=(20, 5))

window_size = 5  
smoothed_intervals = np.convolve(intervalos_RR, np.ones(window_size) / window_size, mode='valid')

plt.plot(smoothed_intervals, marker='o', linestyle='-', color='purple', label='Intervalos R-R suavizados')
plt.axhline(y=media_RR, color='red', linestyle='--', label='Media de Intervalos R-R')
plt.axhline(y=media_RR + desviacion_std_RR, color='green', linestyle='--', label='Media + 1 Desviación Estándar')
plt.axhline(y=media_RR - desviacion_std_RR, color='orange', linestyle='--', label='Media - 1 Desviación Estándar')
plt.title("Duración de los intervalos R-R (Suavizados)")
plt.xlabel("Índice del Intervalo")
plt.ylabel("Duración (s)")
plt.legend()
plt.grid()
plt.show()

#%%TRANSFORMADA WAVELET

scales = np.arange(10, 200)  

# Aplica la CWT(Constant Wavelet Transform) con wavelet Morlet 
coef, freqs = pywt.cwt(intervalos_RR, scales, 'morl', sampling_period=1/fs)

# Normaliza los coeficientes de CWT
coef_norm = np.abs(coef) / np.max(np.abs(coef))

# Graficar el espectrograma con normalización
plt.figure(figsize=(12, 8))
plt.imshow(coef_norm, extent=[tiempo_RR[0], tiempo_RR[-1], freqs[-1], freqs[0]], cmap='jet', aspect='auto')
plt.colorbar(label='Amplitud Normalizada')
plt.ylabel('Frecuencia (Hz)')
plt.xlabel('Tiempo (s)')
plt.title('Espectrograma HRV con CWT (Wavelet Morlet)')
plt.show()